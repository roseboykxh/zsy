<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\4\28 0028
 * Time: 10:13
 */

namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Complaint extends Base{
    //投诉列表
    public function complaint(){
        $Cloud_classroom_category = M('complaint');
        $count = $Cloud_classroom_category->where('1=1')->count();// 查询满足要求的总记录数
        $Page = $pager = new Page($count, 10);// 实例化分页类 传入总记录数和每页显示的记录数
        $list = $Cloud_classroom_category->order('complaint_id ')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $page = $pager->show();//分页显示输出
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('complaint');
    }
    //跳转新增投诉数据
    public function complaintAdd(){
        return $this->fetch('complaintAdd');
    }
    //新增投诉数据
    public function complaintAddHandle(){
        $complaint_name=$_REQUEST['complaint_name'];
        $complaint_phone=$_REQUEST['complaint_phone'];
        $complaint_content=$_REQUEST['complaint_content'];
        $complaint_solve=$_REQUEST['complaint_solve'];
        $complaint_solve_time=$_REQUEST['complaint_solve_time'];
        $complaint_whether=$_REQUEST['complaint_whether'];
        $complaint_unsolved=$_REQUEST['complaint_unsolved'];
        $add_time=date("Y-m-d H:i:s");
        $sql = sprintf("INSERT INTO tp_complaint(complaint_name,complaint_phone,complaint_content,complaint_solve,complaint_solve_time,complaint_whether,complaint_unsolved,add_time) 
VALUES ('%s','%s','%s','%s','%s',%d,'%s','%s')",$complaint_name,$complaint_phone,$complaint_content,$complaint_solve,$complaint_solve_time,$complaint_whether,$complaint_unsolved,$add_time);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/complaint/complaint'));
        } else {
            $this->error("操作失败", U('Admin/complaint/complaint'));
        }
    }
    //跳转查看
    public function complaintSee(){
        $complaint_id=$_REQUEST['complaint_id'];
        $mysql=sprintf("select * from tp_complaint WHERE complaint_id=%d",$complaint_id);
        $res=Db::query($mysql);
        $this->assign('info', $res[0]);
        return $this->fetch('complaintSee');
    }
    //删除一条投诉
    public function complaintDelete(){
        $complaint_id=$_REQUEST['complaint_id'];
        $sql=sprintf("delete from tp_complaint WHERE complaint_id=%d",$complaint_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/complaint/complaint'));
        } else {
            $this->error("操作失败", U('Admin/complaint/complaint'));
        }
    }
}