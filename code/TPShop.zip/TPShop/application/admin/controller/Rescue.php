<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\4\28 0028
 * Time: 13:41
 */

namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Rescue extends Base
{
    public function rescue()
    {
        $Cloud_classroom_category = M('rescue');
        $count = $Cloud_classroom_category->where('1=1')->count();// 查询满足要求的总记录数
        $Page = $pager = new Page($count, 10);// 实例化分页类 传入总记录数和每页显示的记录数
        $list = $Cloud_classroom_category->order('rescue_id ')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $page = $pager->show();//分页显示输出
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('rescue');
    }
    //添加救援
    public function rescueAdd()
    {
        return $this->fetch('rescueAdd');
    }
    public function rescueAddHandle(){
        $rescue_name=$_REQUEST['rescue_name'];
        $rescue_phone=$_REQUEST['rescue_phone'];
        $rescue_license_plate=$_REQUEST['rescue_license_plate'];
        $rescue_address=$_REQUEST['rescue_address'];
        $rescue_content=$_REQUEST['rescue_content'];
        $rescue_solve=$_REQUEST['rescue_solve'];
        $rescue_time=$_REQUEST['rescue_time'];
        $rescue_solve_time=$_REQUEST['rescue_solve_time'];
        $rescue_whether=$_REQUEST['rescue_whether'];
        $rescue_unsolved=$_REQUEST['rescue_unsolved'];
        $add_time=date("Y-m-d h:i:s");
        $sql = sprintf("INSERT INTO tp_rescue(rescue_name,rescue_phone,rescue_license_plate,rescue_address,rescue_content,rescue_solve,
rescue_time,rescue_solve_time,rescue_whether,rescue_unsolved,add_time) 
VALUES ('%s','%s','%s','%s','%s','%s','%s','%s',%d,'%s','%s')",
            $rescue_name,$rescue_phone,$rescue_license_plate,$rescue_address,$rescue_content,$rescue_solve,$rescue_time,$rescue_solve_time,$rescue_whether,
            $rescue_unsolved,$add_time);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/rescue/rescue'));
        } else {
            $this->error("操作失败", U('Admin/rescue/rescue'));
        }
    }
    //删除救援
    public function rescueDelete(){
        $rescue_id = $_REQUEST['rescue_id'];
        $sql = sprintf("delete from tp_rescue WHERE rescue_id=%d", $rescue_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/rescue/rescue'));
        } else {
            $this->error("操作失败", U('Admin/rescue/rescue'));
        }
    }
    //编辑救援
    public function rescueModify(){
        $rescue_id=$_REQUEST['rescue_id'];
        $sql = sprintf("SELECT * FROM tp_rescue WHERE rescue_id=%d",$rescue_id);
        $ret=Db::query($sql);
        $this->assign('info', $ret[0]);// 赋值数据集
        return $this->fetch('rescueModify');
    }
    public function rescueModifyName(){
        $rescue_id=$_REQUEST['rescue_id'];
        $rescue_name=$_REQUEST['rescue_name'];
        $rescue_phone=$_REQUEST['rescue_phone'];
        $rescue_license_plate=$_REQUEST['rescue_license_plate'];
        $rescue_address=$_REQUEST['rescue_address'];
        $rescue_content=$_REQUEST['rescue_content'];
        $rescue_solve=$_REQUEST['rescue_solve'];
        $rescue_time=$_REQUEST['rescue_time'];
        $rescue_solve_time=$_REQUEST['rescue_solve_time'];
        $rescue_whether=$_REQUEST['rescue_whether'];
        $rescue_unsolved=$_REQUEST['rescue_unsolved'];
        $add_time=date("Y-m-d h:i:s");
        $sql = sprintf("UPDATE tp_rescue SET rescue_name='%s',rescue_phone='%s',rescue_license_plate='%s',rescue_address='%s',rescue_content='%s',rescue_solve='%s',
rescue_time='%s',rescue_solve_time='%s',rescue_whether=%d,rescue_unsolved='%s',add_time='%s' WHERE rescue_id=%d",$rescue_name,$rescue_phone,$rescue_license_plate,$rescue_address,$rescue_content,$rescue_solve,$rescue_time,$rescue_solve_time,$rescue_whether,
            $rescue_unsolved,$add_time,$rescue_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/rescue/rescue'));
        } else {
            $this->error("操作失败", U('Admin/rescue/rescue'));
        }
    }
    //查看救援
    public function rescueSee(){
        $rescue_id=$_REQUEST['rescue_id'];
        $sql = sprintf("SELECT * FROM tp_rescue WHERE rescue_id=%d",$rescue_id);
        $ret=Db::query($sql);
        $this->assign('info', $ret[0]);// 赋值数据集
        return $this->fetch('rescueSee');
    }
}