<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\5\11 0011
 * Time: 16:26
 */

namespace app\admin\controller;
use think\AjaxPage;
use think\Controller;
use think\Url;
use think\Config;
use think\Page;
use think\Verify;
use think\Db;
class Insurance extends Base
{
    private $article_system_id = array(1, 2, 3, 4, 5);//系统默认的文章分类id，不可删除
    private $article_main_system_id = array(1, 2);//系统保留分类，不允许在该分类添加文章
    private $article_top_system_id = array(1);//系统分类，不允许在该分类添加新的分类
    private $article_able_id = array(1);//系统预定义文章id，不能删除。此文章用于商品详情售后服务

    public function _initialize()
    {
        parent::_initialize();
        $this->assign('article_top_system_id', $this->article_top_system_id);
        $this->assign('article_system_id', $this->article_system_id);
        $this->assign('article_main_system_id', $this->article_main_system_id);
        $this->assign('article_able_id',$this->article_able_id);
    }
    //交强险列表
    public function insurance(){
        $Cloud_classroom_category = M('insurance');
        $count = $Cloud_classroom_category->where('1=1')->count();// 查询满足要求的总记录数
        $Page = $pager = new Page($count, 10);// 实例化分页类 传入总记录数和每页显示的记录数
        $list = $Cloud_classroom_category->order('insurance_id ')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $page = $pager->show();//分页显示输出
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch();
    }
    //添加交强险
    public function insuranceAdd()
    {
        return $this->fetch('insuranceAdd');
    }
    public function insuranceAddHandle(){
        $insurance_name=$_REQUEST['insurance_name'];
        $insurance_id_number=$_REQUEST['insurance_id_number'];
        $insurance_addressr=$_REQUEST['insurance_address'];
        $insurance_phoner=$_REQUEST['insurance_phone'];
        $license_plate=$_REQUEST['license_plate'];
        $type=$_REQUEST['type'];
        $nature=$_REQUEST['nature'];
        $engine_number=$_REQUEST['engine_number'];
        $distinguish_number=$_REQUEST['distinguish_number'];
        $model=$_REQUEST['model'];
        $people_number=$_REQUEST['people_number'];
        $quality=$_REQUEST['quality'];
        $displacement=$_REQUEST['displacement'];
        $power=$_REQUEST['power'];
        $register_date=$_REQUEST['register_date'];
        $insurance_money=$_REQUEST['insurance_money'];
        $insurance_date=$_REQUEST['insurance_date'];
        $fileName = "/public/upload/business/" . time() . $_FILES["pic"]["name"];
        move_uploaded_file($_FILES["pic"]["tmp_name"], "." . $fileName);
        $add_time=date("Y-m-d h:i:s");
        $sql = sprintf("INSERT INTO tp_insurance(insurance_name,insurance_id_number,insurance_address,insurance_phone,license_plate,type,nature,engine_number,distinguish_number,model,
people_number,quality,displacement,power,register_date,insurance_money,insurance_date,add_time,pic) 
VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
            $insurance_name, $insurance_id_number, $insurance_addressr, $insurance_phoner,$license_plate,$type,$nature,$engine_number,$distinguish_number,$model
        ,$people_number,$quality,$displacement,$power,$register_date,$insurance_money,$insurance_date,$add_time,$fileName);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/insurance/insurance'));
        } else {
            $this->error("操作失败", U('Admin/insurance/insurance'));
        }
    }
    //删除交强险
    public function insuranceDelete(){
        $insurance_id = $_REQUEST['insurance_id'];
        $sql = sprintf("delete from tp_insurance WHERE insurance_id=%d", $insurance_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/insurance/insurance'));
        } else {
            $this->error("操作失败", U('Admin/insurance/insurance'));
        }
    }
    //编辑交强险
    public function insuranceModify(){
        $insurance_id=$_REQUEST['insurance_id'];
        $sql = sprintf("SELECT * FROM tp_insurance WHERE insurance_id=%d",$insurance_id);
        $ret=Db::query($sql);
        $this->assign('info', $ret[0]);// 赋值数据集
        return $this->fetch('insuranceModify');
    }
    //编辑交强险
    public function inspectorModifyName(){
        $insurance_id=$_REQUEST['insurance_id'];
        $insurance_name=$_REQUEST['insurance_name'];
        $insurance_id_number=$_REQUEST['insurance_id_number'];
        $insurance_addressr=$_REQUEST['insurance_address'];
        $insurance_phoner=$_REQUEST['insurance_phone'];
        $license_plate=$_REQUEST['license_plate'];
        $type=$_REQUEST['type'];
        $nature=$_REQUEST['nature'];
        $engine_number=$_REQUEST['engine_number'];
        $distinguish_number=$_REQUEST['distinguish_number'];
        $model=$_REQUEST['model'];
        $people_number=$_REQUEST['people_number'];
        $quality=$_REQUEST['quality'];
        $displacement=$_REQUEST['displacement'];
        $power=$_REQUEST['power'];
        $register_date=$_REQUEST['register_date'];
        $insurance_money=$_REQUEST['insurance_money'];
        $insurance_date=$_REQUEST['insurance_date'];
        $add_time=date("Y-m-d h:i:s");
        $sql = sprintf("UPDATE tp_insurance SET insurance_name = '%s',insurance_id_number='%s',insurance_address='%s',insurance_phone='%s',
license_plate='%s',type='%s',nature='%s',engine_number='%s',distinguish_number='%s',model='%s',
people_number='%s',quality='%s',displacement='%s',power='%s',register_date='%s',insurance_money='%s',
insurance_date='%s',add_time='%s' 
WHERE insurance_id = %d", $insurance_name, $insurance_id_number, $insurance_addressr, $insurance_phoner,$license_plate,$type,$nature,$engine_number,$distinguish_number,$model,$people_number,$quality,$displacement,$power,$register_date,$insurance_money,$insurance_date,$add_time,$insurance_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/insurance/insurance'));
        } else {
            $this->error("操作失败", U('Admin/insurance/insurance'));
        }
    }
    //查看交强险
    public function insuranceSee(){
        $insurance_id=$_REQUEST['insurance_id'];
        $sql = sprintf("SELECT * FROM tp_insurance WHERE insurance_id=%d",$insurance_id);
        $ret=Db::query($sql);
        $this->assign('info', $ret[0]);// 赋值数据集
        return $this->fetch('insuranceSee');
    }
    //编辑信息时查看图片并且跳转
    public function insurancePic(){
        $insurance_id=$_REQUEST['insurance_id'];
        $sql = sprintf("SELECT pic FROM tp_insurance WHERE insurance_id=%d",$insurance_id);
        $ret=Db::query($sql);
        $this->assign('info', $ret[0]);// 赋值数据集
        return $this->fetch('insurance_pic');
    }
}