<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/7/20
 * Time: 9:02
 */

namespace app\admin\controller;


class Garden extends Base {
    public function index(){
        $smsTpls = M('garden')->select();
        $this->assign('smsTplList',$smsTpls);
        return $this->fetch();

    }
    /**
     * 修改
     */
    public function updateGardendist(

    ){
        $id = $_GET['id']; //用户id
        //列表自定义查询列
        $filed = array(
            'id',
            'nickname',//昵称
            'openid',  //OPENID
            'tree_species',  //树的种类
            'tree_amount',// 用户树的数量
            'tree_acreage',// 用户树的总面积
            'tree_name',  //门牌名
            'qr_code',  //二维码
            'remarks',  //备注栏
            'orchard_site', //果园地址
            'provider'  //供货商
        );
        $resArr = M('garden')-> field(implode(',', $filed))->where('id',$id)->select();

        $this->assign('resArr',$resArr);
        return $this->fetch();
    }
    public function updateGardendist2(){
        $kzmArr=explode('.',$_FILES['qr_code']['name']);
        $kzm=$kzmArr[count($kzmArr)-1];
        $newName=time().'.'.$kzm;
        $lastFilePath='/public/upload/qrCode/'.$newName;
        move_uploaded_file($_FILES['qr_code']['tmp_name'],dirname(dirname(dirname(dirname(__FILE__)))).$lastFilePath);

        $id = $_POST['id'];
        $nickname =  $_POST['nickname'];
        $openid = $_POST['openid'];
        $tree_species = $_POST['tree_species'];
        $tree_amount = $_POST['tree_amount'];
        $tree_acreage = $_POST['tree_acreage'];
        $tree_name = $_POST['tree_name'];
        $qr_code = $lastFilePath;
        $remarks = $_POST['remarks'];
        $orchard_site = $_POST['orchard_site'];
        $provider = $_POST['provider'];

        $resArr=  M('garden')->where(array('id'=>$id))->
        save(array(
            'nickname' => $nickname,
            'openid' => $openid,
            'tree_species' => $tree_species,
            'tree_amount' => $tree_amount,
            'tree_acreage' => $tree_acreage,
            'tree_name' => $tree_name,
            'qr_code' => $qr_code,
            'remarks' => $remarks,
            'orchard_site' => $orchard_site,
            'provider' => $provider,));
        $this->assign('resArr',$resArr);
        echo "修改成功";
        header("refresh:1;url=index");//$url就是你的跳转路径
    }

    /**
     * 删除
     */
    public function delGarden(){

        $model = M("garden");
        $row = $model->where('id ='.$_GET['id'])->delete();
        $return_arr = array();
        if ($row){
            $return_arr = array('status' => 1,'msg' => '删除成功','data'  =>'',);   //$return_arr = array('status' => -1,'msg' => '删除失败','data'  =>'',);
        }else{
            $return_arr = array('status' => -1,'msg' => '删除失败','data'  =>'',);
        }
        return $this->ajaxReturn($return_arr);

    }
}