<?php
/**
 * tpshop
 * ============================================================================
 * 版权所有 2015-2027 深圳搜豹网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.tp-shop.cn
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用 .
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * Author: 当燃
 * Date: 2015-09-09
 */
namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Worktime extends Base
{

    private $article_system_id = array(1, 2, 3, 4, 5);//系统默认的文章分类id，不可删除
    private $article_main_system_id = array(1, 2);//系统保留分类，不允许在该分类添加文章
    private $article_top_system_id = array(1);//系统分类，不允许在该分类添加新的分类
    private $article_able_id = array(1);//系统预定义文章id，不能删除。此文章用于商品详情售后服务

    public function _initialize()
    {
        parent::_initialize();
        $this->assign('article_top_system_id', $this->article_top_system_id);
        $this->assign('article_system_id', $this->article_system_id);
        $this->assign('article_main_system_id', $this->article_main_system_id);
        $this->assign('article_able_id', $this->article_able_id);
    }

    public function worktimeList()
    {
        $Cloud_worktime = M('Cloud_worktime ');
        $list = array();
        $size = input('size/d', 20);
        $where = array();
        $sql=sprintf("select * from tp_cloud_worktime ORDER BY week");
        $a = Db::query($sql);
        $ary=array(0=>'星期日',1=>'星期一',2=>'星期二',3=>'星期三',4=>'星期四',5=>'星期五',6=>'星期六');

//      var_dump($a);exit;
        $count = $Cloud_worktime ->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出
        //下拉列表添加
        for($i=0;$i<count($a);$i++){
            $a[$i]['if_work']=$a[$i]['if_work']==1?'是':'否';
        }
        for($i=0;$i<count($a);$i++){
            $a[$i]['week']=$ary[$a[$i]['week']];
        }
//        var_dump($a);exit;


        $this->assign('result', $a);
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('worktimeList');
    }

    public function worktimeAdd1()
    {
        //接收信息
        $param  =   array(
            'week'  =>  $_POST['week'],
            'monstart_time'  =>  $_POST['monstart_time'],
            'monend_time'  =>  $_POST['monend_time'],
            'aftstart_time'  =>  $_POST['aftstart_time'],
            'aftend_time'  =>  $_POST['aftend_time'],
            'if_work'  =>  $_POST['if_work']
        );
        //判断星期是否存在
        $week=$_POST['week'];//接收传值
        $mysql = sprintf("select week from tp_cloud_worktime WHERE week=%d",$week);
        $res = Db::query($mysql);
//        var_dump($res);exit;
            if(!empty($res)) {
                echo "<script type='text/javascript'>alert('该星期信息已存在，请重新输入！');location.href='worktimeAdd';</script>";
            }
            else{
                $sql=sprintf("insert into tp_cloud_worktime (week,monstart_time,monend_time,aftstart_time,aftend_time,if_work) 
                        VALUES ('%s','%s','%s','%s','%s',%d)",$param['week'],$param['monstart_time'],$param['monend_time'],$param['aftstart_time'],$param['aftend_time'],$param['if_work']);
                $a=Db::query($sql);
        }

        $this->assign('aaa',$a);
        if ($sql) {
            $this->success("操作成功", U('Admin/Worktime/worktimeList'));
        } else {
            $this->error("操作失败", U('Admin/Worktime/worktimeList'));
        }
    }

    public function worktimeAdd()
    {

        $act = I('get.act', 'add');
        $data['add_time'] = date("Y-m-d H:m:s", time());

        $this->assign('act', $act);
        return $this->fetch();

    }

    /**
     * 初始化编辑器链接
     * @param $post_id post_id
     */
    private function initEditor()
    {
        $this->assign("URL_upload", U('Admin/Ueditor/imageUp', array('savepath' => 'article')));
        $this->assign("URL_fileUp", U('Admin/Ueditor/fileUp', array('savepath' => 'article')));
        $this->assign("URL_scrawlUp", U('Admin/Ueditor/scrawlUp', array('savepath' => 'article')));
        $this->assign("URL_getRemoteImage", U('Admin/Ueditor/getRemoteImage', array('savepath' => 'article')));
        $this->assign("URL_imageManager", U('Admin/Ueditor/imageManager', array('savepath' => 'article')));
        $this->assign("URL_imageUp", U('Admin/Ueditor/imageUp', array('savepath' => 'article')));
        $this->assign("URL_getMovie", U('Admin/Ueditor/getMovie', array('savepath' => 'article')));
        $this->assign("URL_Home", "");
    }

    public function worktimeEditHandle()
    {
        $dddd = $_GET['work_id'];
        $sql = sprintf("select tp_cloud_worktime.* from tp_cloud_worktime WHERE tp_cloud_worktime.work_id=%d", $dddd);
        $a = Db::query($sql);

        for($i=0;$i<count($a);$i++){
            $a[$i]['if_work']=$a[$i]['if_work']==1?'是':'否';
        }
        $ary=array(0=>'星期日',1=>'星期一',2=>'星期二',3=>'星期三',4=>'星期四',5=>'星期五',6=>'星期六');
        for($i=0;$i<count($a);$i++){
            $a[$i]['week']=$ary[$a[$i]['week']];
        }
//      var_dump($a);exit;
        $this->assign('result', $a[0]);
        return $this->fetch('worktimeEdit');
    }

    public function worktimeEdit()
    {
        $act = I('get.act', 'add');
        $info = array();
        $data['add_time'] = date("Y-m-d H:m:s", time());

        $work_id = I('get.work_id/d');
        if ($work_id) {
            $info = D('cloud_worktime')->where('work_id', $work_id)->find();
        }

        $this->assign('act', $act);
        $this->assign('info', $info);
        $this->initEditor();
        return $this->fetch();
    }

    public function worktimeUpdate()
    {
        $work_id=$_GET['work_id'];
        $monstart_time = $_POST['monstart_time'];
        $monend_time = $_POST['monend_time'];
        $aftstart_time = $_POST['aftstart_time'];
        $aftend_time = $_POST['aftend_time'];
        $if_work = $_POST['if_work'];
        $sql = sprintf("UPDATE tp_cloud_worktime SET monstart_time = '%s',monend_time = '%s',aftstart_time = '%s',aftend_time = '%s',if_work = %d WHERE work_id = %d", $monstart_time, $monend_time,$aftstart_time,$aftend_time,$if_work,$work_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/Worktime/worktimeList'));
        } else {
            $this->error("操作失败", U('Admin/Worktime/worktimeList'));
        }

    }

    public function worktimeDelete()
    {
        $Cloud_worktime = M('Cloud_worktime ');
        $list = array();
        $size = input('size/d', 20);
        $where = array();
        $count = $Cloud_worktime ->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        $data = I('get.');
//        var_dump($data);exit;
        $sql=sprintf("delete from tp_cloud_worktime WHERE work_id=%d",$data['work_id']);
        Db::query($sql);

        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);

        if ($sql) {
            $this->success("操作成功", U('Admin/Worktime/worktimeList'));
        } else {
            $this->error("操作失败", U('Admin/Worktime/worktimeList'));
        }

    }
}