<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\4\18 0018
 * Time: 10:16
 */

namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Prepare extends Base
{
//预约列表
    public function prepare()
    {
        $Cloud_classroom_category = M('prepare');
        $count = $Cloud_classroom_category->where('1=1')->count();// 查询满足要求的总记录数
        $Page = $pager = new Page($count, 10);// 实例化分页类 传入总记录数和每页显示的记录数
        $list = $Cloud_classroom_category->order('prepare_id ')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $page = $pager->show();//分页显示输出
        for ($i = 0; $i < count($list); $i++) {
            $sql1 = sprintf("SELECT * FROM tp_distribution WHERE prepare_id=%d", $list[$i]['prepare_id']);
            $ret1 = Db::query($sql1);
            $list[$i]['aa'] = $ret1[0];
        }
        $data['add_time'] = date("Y-m-d H:m:s", time());
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('prepare');
    }

    //预约删除
    public function PrepareDelete()
    {
        $prepare_id = $_REQUEST['prepare_id'];
        $sql1 = sprintf("delete from tp_prepare WHERE prepare_id=%d", $prepare_id);
        Db::query($sql1);
        $sql = sprintf("delete from tp_prepare_info WHERE prepare_id=%d", $prepare_id);
        Db::query($sql);
        $sql2 = sprintf("delete from tp_distribution WHERE prepare_id=%d", $prepare_id);
        Db::query($sql2);
        if ($sql) {
            $this->success("操作成功", U('Admin/Prepare/prepare'));
        } else {
            $this->error("操作失败", U('Admin/Prepare/prepare'));
        }
    }

    //分配预约车辆
    public function distribution()
    {
        $prepare_id = $_REQUEST['prepare_id'];
        $sql = sprintf("SELECT inspector_id,inspector_name FROM tp_inspector");
        $ret = Db::query($sql);
        for ($i = 0; $i < count($ret); $i++) {
            $sql1 = sprintf("SELECT * FROM tp_distribution WHERE inspector_id=%d AND complete=1 AND yes_no=1", $ret[$i]['inspector_id']);
            $ret1 = Db::query($sql1);
            $a = count($ret1);
            $ret[$i]['num'] = $a;
        }
        $this->assign('prepare_id', $prepare_id);// 预约车辆ID
        $this->assign('ret', $ret);//检车员的姓名和正在检车数量
        return $this->fetch('distribution');
    }

//http_post请求代码，复制即可不用修改
    private function http_post($api_url = '', $param = array(), $timeout = 5)
    {
        if (!$api_url) {
            die("error api_url");
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);

        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        if (parse_url($api_url)['scheme'] == 'https') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        }
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, 'api:key-' . $this->_api_key);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        $res = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        if ($error) {
            $this->_last_error[] = $error;
            return FALSE;
        }
        return $res;
    }

//    //测试，接受表单提交过来的数据
//    public function sendmessage()
//    {
//        $post_data['userid'] = '8M00021';    //企业id，不验证
//        $post_data['account'] = '8M00021';    //用户名
//        $pwd = md5('8M0002144');            //密码，需要使用md5加密
//        $post_data['password'] = $pwd;
//        $post_data['mobile'] = $_POST['mobile'];    //要发送的手机号
//        $post_data['content'] = $_POST['content'];    //发送的内容，需要在短信管理平台报备模板
//        $post_data['sendTime'] = '';            //设置发送时间，默认为空，默认即时发送
//        $post_data['extno'] = '';            //扩展子号，默认为空
//        $url = "https://dx.ipyy.net/smsJson.aspx?action=send";        //短信发送接口请求地址
//        $res = $this->http_post($url, $post_data);            //请求http_post
//        $state = json_decode($res);
//        $call = $state->returnstatus;
//        if ($call == "Success") {
//            $time = time();
//            $time1 = date("Y-m-d H:i:s", $time);
//            $sql = sprintf("INSERT INTO tp_send_message_log(time)
//VALUES ('%s')", $time1);
//            Db::query($sql);
//        }
//        print $res;
//    }

    //车辆预约分配并添加
    public function distributionAdd()
    {
        $prepare_id = $_REQUEST['prepare_id'];
        $inspector_id = $_REQUEST['inspector_id'];
        $sql = sprintf("SELECT * FROM tp_distribution WHERE prepare_id=%d AND inspector_id=%d", $prepare_id,$inspector_id);
        $ret = Db::query($sql);
        $sql1 = sprintf("SELECT inspector_phone FROM tp_inspector WHERE inspector_id=%d ", $inspector_id);
        $ret1 = Db::query($sql1);
        $sql3 = sprintf("SELECT * FROM tp_prepare WHERE prepare_id=%d ", $prepare_id);
        $ret3 = Db::query($sql3);
        $contacts_name = $ret3[0]['contacts_name'];
        $contacts_phone = $ret3[0]['contacts_phone'];//联系人电话
        $inspector_phone = $ret1[0]['inspector_phone'];
        $content = "为你分配订单号是：$prepare_id,联系人姓名：'$contacts_name'，联系人电话：'$contacts_phone'，请你及时与车主联系！【迅达】";
        if ($ret[0]==0) {
        $post_data['userid'] = '8M00021';    //企业id，不验证
        $post_data['account'] = '8M00021';    //用户名
        $pwd = md5('8M0002144');            //密码，需要使用md5加密
        $post_data['password'] = $pwd;
        $post_data['mobile'] = $inspector_phone;    //要发送的手机号
        $post_data['content'] = $content;    //发送的内容，需要在短信管理平台报备模板
        $post_data['sendTime'] = '';            //设置发送时间，默认为空，默认即时发送
        $post_data['extno'] = '';            //扩展子号，默认为空
        $url = "https://dx.ipyy.net/smsJson.aspx?action=send";        //短信发送接口请求地址
        $res = $this->http_post($url, $post_data);            //请求http_post
        $state = json_decode($res);
        $call = $state->returnstatus;
        if ($call == "Success") {
            $time = time();
            $time1 = date("Y-m-d H:i:s", $time);
            $sql2 = sprintf("INSERT INTO tp_send_message_log(time,phone)
VALUES ('%s','%s')", $time1, $post_data['mobile']);
            Db::query($sql2);
        }
        $sql = sprintf("INSERT INTO tp_distribution(prepare_id,inspector_id,complete,add_time)
VALUES (%d,%d,%d,'%s')", $prepare_id, $inspector_id,0,$time1);
        Db::query($sql);

            $this->success("分配成功", U('Admin/Prepare/prepare'));
        } else {
            $this->error("已分配过", U('Admin/Prepare/prepare'));
        }
    }
}