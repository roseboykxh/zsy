<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/5/17
 * Time: 10:31
 */

namespace app\admin\controller;


class texta
{
    public function text()
    {
        $mm = M('tp_group_buy');
        $title = $_POST['title'];
        $goods_name = $_POST['goods_name'];
        $goods_id = $_POST['goods_id'];
        $count = $mm->count();
        $Page = new \Think\Page($count, 2);
        // $Page->setConfig('header','个组织');
        $Page->setConfig('first', '第一页');
        $Page->setConfig('prev', '前一页');
        $Page->setConfig('next', '后一页');
        $Page->setConfig('last', '最后一页');
        $Page->setConfig('theme', "<ul class='pagination'></li><li>%UP_PAGE% %LINK_PAGE% %DOWN_PAGE%</li><li><a> %HEADER%  %NOW_PAGE%/%TOTAL_PAGE% 页</a></ul>");
        $show = $Page->show();
        $map['title'] = array('like', '%' . $_POST['title'] . '%');
        $list = $mm->where($map)->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $this->assign('list', $list);
        $this->disply(texta);
    }
}