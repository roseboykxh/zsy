<?php
/**
 * tpshop
 * ============================================================================
 * 版权所有 2015-2027 深圳搜豹网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.tp-shop.cn
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用 .
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * Author: 当燃      
 * Date: 2015-09-09
 */
namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Cloud extends Base {

    private $article_system_id = array(1, 2, 3, 4, 5);//系统默认的文章分类id，不可删除
    private $article_main_system_id = array(1, 2);//系统保留分类，不允许在该分类添加文章
    private $article_top_system_id = array(1);//系统分类，不允许在该分类添加新的分类
    private $article_able_id = array(1);//系统预定义文章id，不能删除。此文章用于商品详情售后服务

    public function _initialize()
    {
        parent::_initialize();
        $this->assign('article_top_system_id', $this->article_top_system_id);
        $this->assign('article_system_id', $this->article_system_id);
        $this->assign('article_main_system_id', $this->article_main_system_id);
        $this->assign('article_able_id',$this->article_able_id);
    }
    public function cloudSort(){
        $Cloud_classroom_category =  M('Cloud_classroom_category');
        $p = input('p/d', 1);
        $size = input('size/d', 20);
        $where = array();
        $keywords = trim(I('keywords'));
        $keywords && $where['cr_name'] = array('like', '%' . $keywords . '%');
        $cat_id = I('cat_id/d',0);
        $cat_id && $where['cat_id'] = $cat_id;
        $res = $Cloud_classroom_category->where($where)->order('crt_id desc')->page("$p,$size")->select();
//        dump($res);exit;
        $count = $Cloud_classroom_category->where('1=1')->count();// 查询满足要求的总记录数
        $Page = $pager = new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
        $res = $Cloud_classroom_category->order('crt_id ')->limit($Page->firstRow.','.$Page->listRows)->select();
        $page = $pager->show();//分页显示输出
        $list = array();
        if($res){
        	foreach ($res as $val){
        		$list[] = $val;
        	}
        }
//        var_dump($list);exit;
        for($i=0;$i<count($list);$i++){
            $list[$i]['state']=$list[$i]['state']==1?'正常':'停止使用';

        }
        $data['add_time'] =date("Y-m-d H:m:s",time());
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$page);// 赋值分页输出
        $this->assign('pager',$pager);
        return $this->fetch('cloudSort');
    }
    
    public function cloudSortAdd(){
 		$act = I('get.act','add');
        $info = array();
        $info['add_time'] = time()+3600*24;
        $data['add_time'] =date("Y-m-d H:m:s",time());

        $this->assign('act',$act);
//        $this->initEditor();
        return $this->fetch();
    }
    public function cloudSortEdit(){
        $act = I('get.act','add');
        $info = array();
        $data['add_time'] =date("Y-m-d H:m:s",time());

        $crt_id = I('get.crt_id/d');
        if($crt_id){
            $info = D('cloud_classroom_category')->where('crt_id', $crt_id)->find();
        }
//var_dump($info);exit;
        $this->assign('act',$act);
        $this->assign('info',$info);
        $this->initEditor();
        return $this->fetch();
    }

    /**
     * 初始化编辑器链接
     * @param $post_id post_id
     */
    private function initEditor()
    {
        $this->assign("URL_upload", U('Admin/Ueditor/imageUp',array('savepath'=>'article')));
        $this->assign("URL_fileUp", U('Admin/Ueditor/fileUp',array('savepath'=>'article')));
        $this->assign("URL_scrawlUp", U('Admin/Ueditor/scrawlUp',array('savepath'=>'article')));
        $this->assign("URL_getRemoteImage", U('Admin/Ueditor/getRemoteImage',array('savepath'=>'article')));
        $this->assign("URL_imageManager", U('Admin/Ueditor/imageManager',array('savepath'=>'article')));
        $this->assign("URL_imageUp", U('Admin/Ueditor/imageUp',array('savepath'=>'article')));
        $this->assign("URL_getMovie", U('Admin/Ueditor/getMovie',array('savepath'=>'article')));
        $this->assign("URL_Home", "");
    }
    
    public function cloudSortAddHandle(){
       // var_dump($_FILES);
       // var_dump($_FILES["img"]["size"]);exit;

        $fileName = "/public/upload/cloud/".$_FILES["img"]["name"];
        move_uploaded_file($_FILES["img"]["tmp_name"], "." . $fileName);
        $data = I('post.');
        //var_dump($data);exit;
        $aaa['cr_name']=$data['cr_name'];
        $aaa['sort']=$data['sort'];
        $aaa['state']=$data['state'];

        $url = $this->request->server('HTTP_REFERER');
        $referurl = !empty($url) ? $url : U('Admin/Cloud/cloudSort');

        $cr_name=$_POST['cr_name'];
        $mysql=sprintf("select cr_name from tp_cloud_classroom_category WHERE cr_name='%s'",$cr_name);
        $res=Db::query($mysql);
//        var_dump($res);exit;
        if(!empty($res)){
            echo "<script type='text/javascript'>alert('该课程分类已存在，请重新输入！');location.href='cloudSortAdd';</script>";
        }else{
            $data['click'] = mt_rand(1000,1300);
            $data['add_time'] =date("Y-m-d H:m:s",time()) ;
            $data['img'] = $fileName;
            $r = D('cloud_classroom_category')->add($data);
        }

        $sort=$_POST['sort'];
        $mysql=sprintf("select sort from tp_cloud_classroom_category WHERE sort=%d",$sort);
        $res=Db::query($mysql);
        if(!empty($res)){
            echo "<script type='text/javascript'>alert('该课程排序已存在，请重新输入！');location.href='cloudSortAdd';</script>";
        }else{
            $data['click'] = mt_rand(1000,1300);
            $data['add_time'] =date("Y-m-d H:m:s",time()) ;
            $data['img'] = $fileName;
            $r = D('cloud_classroom_category')->add($data);
        }

        if($data['act'] == 'add'){

            if(array_key_exists($data['cat_id'],$this->article_main_system_id)){
                $this->error("不能在系统保留分类下添加文章,操作失败",$referurl);

            }



        }

        if($data['act'] == 'edit'){
            //var_dump($fileName);exit;
            $data['img'] = $fileName;
           // var_dump($fileName);exit;
            if($_FILES["img"]["size"]>0){
                $r = M('cloud_classroom_category')->where('crt_id', $data['crt_id'])->save($data);
            }else{
                $r = M('cloud_classroom_category')->where('crt_id', $data['crt_id'])->save($aaa);
            }

        }
//        $r = D('cloud_classroom_category')->update($data);

        if($data['act'] == 'del'){
            $r = D('cloud_classroom_category')->where('crt_id', $data['del_id'])->delete();
            if($r) exit(json_encode(1));
        }
        $referurl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : U('Admin/Cloud/cloudSort');
        // 不管是添加还是修改广告 都清除一下缓存
        delFile(RUNTIME_PATH.'html'); // 先清除缓存, 否则不好预览

        if($r){
            $this->success("操作成功",U('Admin/Cloud/cloudSort'));
        }else{
            $this->error("操作失败",$referurl);
        }
    }

    public function cloudListDelete()
    {
        $Cloud_classroom_category = M('Cloud_classroom_category ');
        $list = array();
        $size = input('size/d', 20);
        $where = array();
        $count = $Cloud_classroom_category ->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        $data = I('get.');
//        var_dump($data);exit;
        $sql=sprintf("delete from tp_cloud_classroom_category WHERE crt_id=%d",$data['work_id']);
        Db::query($sql);

        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);

        if ($sql) {
            $this->success("操作成功", U('Admin/Cloud/cloudSort'));
        } else {
            $this->error("操作失败", U('Admin/Cloud/cloudSort'));
        }

    }

    public function lessonDetail()
    {

//        var_dump($_REQUEST['crt_id']);exit;
        $Cloud_classroom_detail = M('Cloud_classroom_detail');
        $list = array();
        $p = input('p/d', 1);
        $size = input('size/d', 20);
        $where = array();
        $keywords = trim(I('keywords'));
        $keywords && $where['v_name'] = array('like', '%' . $keywords . '%');
//        $res = $Cloud_classroom_detail->where($where)->order('crd_id desc')->page("$p,$size")->select();
        $sql = sprintf("select tp_cloud_classroom_detail.crd_id,tp_cloud_classroom_detail.v_img,
                      tp_cloud_classroom_detail.v_name,tp_cloud_classroom_detail.v_intro,tp_cloud_classroom_detail.add_time,
                      tp_cloud_classroom_detail.v_path,tp_cloud_classroom_category.crt_id,tp_cloud_classroom_category.cr_name,tp_cloud_author.a_name from (tp_cloud_classroom_detail
                      left JOIN tp_cloud_classroom_category ON tp_cloud_classroom_detail.crt_id=tp_cloud_classroom_category.crt_id)
                      LEFT JOIN tp_cloud_author ON tp_cloud_classroom_detail.author_id=tp_cloud_author.author_id 
                      WHERE tp_cloud_classroom_category.crt_id='%s' ORDER BY crd_id" ,$_GET['crt_id']);
        $a = Db::query($sql);
//        var_dump($a);exit;
        $count = $Cloud_classroom_detail->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出
        if ($a) {
            foreach ($a as $val) {
                $list[] = $val;
            }
        }
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('lessonDetail');
    }

    public function lessonDetailAdd()
    {
        $act = I('get.act', 'add');
        $info = array();
        $info['add_time'] = time() + 3600 * 24;
        $data['add_time'] = date("Y-m-d H:m:s", time());

        $category = D('cloud_classroom_category')->select();
        $this->assign('category', $category);

        $author = D('cloud_author')->select();
        $this->assign('author', $author);

//        var_dump($category);exit;
        $this->assign('act', $act);
        return $this->fetch();
    }

    public function lessonDetailEdit()
    {
        $act = I('get.act','add');
        $info = array();
        $data['add_time'] =date("Y-m-d H:m:s",time());
        $crd_id = I('get.crd_id/d');
//        var_dump($crd_id);exit;
        if($crd_id){
            $info = D('cloud_classroom_detail')->where('crd_id', $crd_id)->find();
        }
//        var_dump($info);exit;
        $category = D('cloud_classroom_category')->select();
        $this->assign('category', $category);

        $author = D('cloud_author')->select();
        $this->assign('author', $author);

        $this->assign('act',$act);
        $this->assign('info',$info);
        $this->initEditor();
        return $this->fetch();
    }

    public function detail(){
//        var_dump($_GET['crt_id']);exit;
        $Cloud_classroom_detail = M('Cloud_classroom_detail');
        $list = array();
        $p = input('p/d', 1);
        $size = input('size/d', 20);
        $where = array();
        $res = $Cloud_classroom_detail->where($where)->order('crd_id desc')->page("$p,$size")->select();
        $sql = sprintf("select tp_cloud_classroom_detail.crd_id,tp_cloud_classroom_detail.v_img,
                      tp_cloud_classroom_detail.v_name,tp_cloud_classroom_detail.v_intro,tp_cloud_classroom_detail.add_time,
                      tp_cloud_classroom_detail.v_path,tp_cloud_classroom_category.crt_id,tp_cloud_classroom_category.cr_name,tp_cloud_author.a_name from (tp_cloud_classroom_detail
                      left JOIN tp_cloud_classroom_category ON tp_cloud_classroom_detail.crt_id=tp_cloud_classroom_category.crt_id)
                      LEFT JOIN tp_cloud_author ON tp_cloud_classroom_detail.author_id=tp_cloud_author.author_id 
                      WHERE tp_cloud_classroom_category.crt_id='%s' ORDER BY crd_id" ,$_GET['crt_id']);
        $a = Db::query($sql);
//        var_dump($a);exit;
        $count = $Cloud_classroom_detail->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        if ($a) {
            foreach ($a as $val) {
                $list[] = $val;
            }
        }
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('lessonDetail');
    }

    public function lessonDetailAddHandle()
    {
        $fileName = "/public/upload/cloud/".$_FILES["v_img"]["name"];
        move_uploaded_file($_FILES["v_img"]["tmp_name"], "." . $fileName);
        $data = I('post.');
        $aaa['v_name']=$data['v_name'];
        $aaa['v_intro']=$data['v_intro'];
        $aaa['v_path']=$data['v_path'];
        $aaa['cr_name']=$data['cr_name'];
        $aaa['a_name']=$data['a_name'];
        $url = $this->request->server('HTTP_REFERER');
        $referurl = !empty($url) ? $url : U('Admin/Cloud/Detail1');

        if($data['act'] == 'add'){

            if(array_key_exists($data['cat_id'],$this->article_main_system_id)){
                $this->error("不能在系统保留分类下添加文章,操作失败",$referurl);

            }

            $data['click'] = mt_rand(1000,1300);
            $data['add_time'] =date("Y-m-d H:m:s",time()) ;
            $data['v_img'] = $fileName;
            $r = D('cloud_classroom_detail')->add($data);

        }

        if($data['act'] == 'edit'){
            //var_dump($fileName);exit;
            $data['v_img'] = $fileName;
            // var_dump($fileName);exit;

            if($_FILES["v_img"]["size"]>0){
                $r = M('cloud_classroom_detail')->where('crd_id', $data['crd_id'])->save($data);
            }else{
                $r = M('cloud_classroom_detail')->where('crd_id', $data['crd_id'])->save($aaa);
            }

        }
//        $r = D('cloud_classroom_category')->update($data);

        if($data['act'] == 'del'){
            $r = D('cloud_classroom_detail')->where('crd_id', $data['del_id'])->delete();
            if($r) exit(json_encode(1));
        }
        $referurl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : U('Admin/Cloud/LessonDetail');
        // 不管是添加还是修改广告 都清除一下缓存
        delFile(RUNTIME_PATH.'html'); // 先清除缓存, 否则不好预览

        if($r){
            $this->success("操作成功",U("Admin/Cloud/LessonDetail?crt_id={$data['crt_id']}"));
        }else{
            $this->error("操作失败",$referurl);
        }
    }


}