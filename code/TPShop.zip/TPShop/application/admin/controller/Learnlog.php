<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/30
 * Time: 9:33
 */

namespace app\admin\controller;
use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Learnlog extends Base
{
    public function learnlog(){
        $Classroom_detail =  M('cloud_em_study_log');
        $list = array();
        $p = input('p/d', 1);
        $size = input('size/d', 20);
        $where = array();
        $keywords = trim(I('keywords'));
        $keywords && $where['v_name'] = array('like', '%' . $keywords . '%');
        $cat_id = I('log_id/d',0);
        $cat_id && $where['log_id'] = $cat_id;
        $res = $Classroom_detail->where($where)->order('log_id desc')->page("$p,$size")->select();
        $count = $Classroom_detail->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count,$size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        if($res){
            foreach ($res as $val){
                $list[] = $val;
            }
        }
        $sql = sprintf("select tp_cloud_em_study_log.*,tp_cloud_employee.em_name,tp_cloud_classroom_detail.v_name,tp_cloud_classroom_category.cr_name from (tp_cloud_em_study_log 
                      left join tp_cloud_employee on tp_cloud_em_study_log.employee_id=tp_cloud_employee.employee_id) 
                      left join tp_cloud_classroom_detail on tp_cloud_em_study_log.crd_id=tp_cloud_classroom_detail.crd_id
                      left join tp_cloud_classroom_category on tp_cloud_em_study_log.crt_id=tp_cloud_classroom_category.crt_id
                       ");
        $result = Db::query($sql);
        $this->assign('result',$result);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$page);// 赋值分页输出
        $this->assign('pager',$pager);
        return $this->fetch();
    }
}