<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\4\20 0020
 * Time: 13:41
 */

namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;
class Inspector extends Base
{
    //检车员列表
    public function inspector()
    {
        $Cloud_classroom_category = M('inspector');
        $count = $Cloud_classroom_category->where('1=1')->count();// 查询满足要求的总记录数
        $Page = $pager = new Page($count, 10);// 实例化分页类 传入总记录数和每页显示的记录数
        $list = $Cloud_classroom_category->order('inspector_id ')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $page = $pager->show();//分页显示输出
        for($i=0;$i<count($list);$i++){
            $sql1=sprintf("SELECT * FROM tp_distribution WHERE inspector_id=%d AND complete=0",$list[$i]['inspector_id']);
            $ret1=Db::query($sql1);
            $a=count($ret1);
            $list[$i]['num']=$a;
        }
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch();
    }
    //删除检车员
    public function inspectorDelete()
    {
        $inspector_id = $_REQUEST['inspector_id'];
        $sql = sprintf("delete from tp_inspector WHERE inspector_id=%d", $inspector_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/inspector/inspector'));
        } else {
            $this->error("操作失败", U('Admin/inspector/inspector'));
        }
    }
    //添加检车员
    public function inspectorAdd()
    {
        $Cloud_classroom_category = M('inspector');
        $this->assign('list', $Cloud_classroom_category);// 赋值数据集
        return $this->fetch('inspectorAdd');
    }
    public function inspectorAddHandle(){
        $inspector_name=$_REQUEST['inspector_name'];
        $inspector_phone=$_REQUEST['inspector_phone'];
        $inspector_job_number=$_REQUEST['inspector_job_number'];
        $add_time=date("Y-m-d h:i:s");
        $sql = sprintf("INSERT INTO tp_inspector(inspector_name,inspector_phone,inspector_job_number,add_time) 
VALUES ('%s','%s','%s','%s')", $inspector_name, $inspector_phone, $inspector_job_number, $add_time);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/inspector/inspector'));
        } else {
            $this->error("操作失败", U('Admin/inspector/inspector'));
        }
    }
    //编辑检车员先查询
    public function inspectorModify()
    {
        $inspector_id=$_REQUEST['inspector_id'];
        $sql = sprintf("SELECT * FROM tp_inspector WHERE inspector_id=%d",$inspector_id);
        $ret=Db::query($sql);
        $this->assign('list', $ret[0]);// 赋值数据集
        return $this->fetch('inspectorModify');
    }
    //编辑检车员
    public function inspectorModifyName(){
        $inspector_id=$_REQUEST['inspector_id'];
        $inspector_name=$_REQUEST['inspector_name'];
        $inspector_phone=$_REQUEST['inspector_phone'];
        $inspector_job_number=$_REQUEST['inspector_job_number'];
        $add_time=date("Y-m-d H:i:s");
        $sql = sprintf("UPDATE tp_inspector SET inspector_name = '%s',inspector_phone='%s',inspector_job_number='%s',add_time='%s' 
WHERE inspector_id = %d",$inspector_name,$inspector_phone,$inspector_job_number,$add_time,$inspector_id);
        Db::query($sql);
        if ($sql) {
            $this->success("操作成功", U('Admin/inspector/inspector'));
        } else {
            $this->error("操作失败", U('Admin/inspector/inspector'));
        }
    }
}