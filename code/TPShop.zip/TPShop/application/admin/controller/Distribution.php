<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\4\24 0024
 * Time: 13:27
 */

namespace app\admin\controller;
use think\Page;
use think\Db;
class Distribution extends Base
{
    //分配列表
    public function distribution()
    {
        $Cloud_classroom_category = M('distribution');
        $count = $Cloud_classroom_category->where('1=1')->count();// 查询满足要求的总记录数
        $Page = $pager = new Page($count, 10);// 实例化分页类 传入总记录数和每页显示的记录数
        $list = $Cloud_classroom_category->order( 'id' )->limit($Page->firstRow . ',' . $Page->listRows)->select();
        for($i=0;$i<count($list);$i++){
            $sql1=sprintf("SELECT prepare_id,contacts_name,contacts_phone FROM tp_prepare WHERE prepare_id=%d",$list[$i]['prepare_id']);
            $ret1=Db::query($sql1);
            $sql=sprintf("SELECT inspector_name FROM tp_inspector WHERE inspector_id=%d",$list[$i]['inspector_id']);
            $ret=Db::query($sql);
            $list[$i]['aaa']=$ret;
            $list[$i]['bbb']=$ret1;
        }
        $page = $pager->show();//分页显示输出
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch();
    }
    //删除已分配的预约车辆
    public function distributionDelete(){
        $id=$_REQUEST['id'];
        $prepare_id = $_REQUEST['prepare_id'];
        $complete=$_REQUEST['complete'];
        if ($complete==1) {
            $sql = sprintf("UPDATE tp_distribution SET  complete =1,yes_no=0 WHERE prepare_id=%d",$prepare_id);
            Db::query($sql);
            $sql = sprintf("UPDATE tp_distribution SET yes_no=1 WHERE id=%d",$id);
            Db::query($sql);
            $this->success("操作成功", U("Admin/Distribution/distribution?id=$id"));
        } else if ($complete==2){
            $sql = sprintf("UPDATE tp_distribution SET complete = '2' WHERE id=%d",$id);
            Db::query($sql);
            $this->success("操作成功", U('Admin/Distribution/distribution'));
        }else if($complete==3){
            $sql = sprintf("UPDATE tp_distribution SET complete =3  WHERE id=%d",$id);
            Db::query($sql);
            $sql = sprintf("UPDATE tp_distribution SET  complete =3 WHERE prepare_id=%d",$prepare_id);
            Db::query($sql);
            $this->success("操作成功", U('Admin/Distribution/distribution'));
        }else{
            $this->error("操作失败", U('Admin/Distribution/distribution'));
        }
    }
}