<?php
/**
 * tpshop
 * ============================================================================
 * 版权所有 2015-2027 深圳搜豹网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.tp-shop.cn
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用 .
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * Author: 当燃
 * Date: 2015-09-09
 */
namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Entertainment extends Base
{

    private $article_system_id = array(1, 2, 3, 4, 5);//系统默认的文章分类id，不可删除
    private $article_main_system_id = array(1, 2);//系统保留分类，不允许在该分类添加文章
    private $article_top_system_id = array(1);//系统分类，不允许在该分类添加新的分类
    private $article_able_id = array(1);//系统预定义文章id，不能删除。此文章用于商品详情售后服务

    public function _initialize()
    {
        parent::_initialize();
        $this->assign('article_top_system_id', $this->article_top_system_id);
        $this->assign('article_system_id', $this->article_system_id);
        $this->assign('article_main_system_id', $this->article_main_system_id);
        $this->assign('article_able_id', $this->article_able_id);
    }

    public function enterSortList()
    {
        $Entertainment = M('Entertainment');
        $size = input('size/d', 20);
        $where = array();

        $sql=sprintf("select tp_entertainment.* from tp_entertainment ORDER BY en_id ASC ");
        $a=Db::query($sql);

        $count = $Entertainment->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        $list = array();
        for ($i=0;$i<count($list);$i++){
            $list[$i]['state']=$list[$i]['state']==1?'正常':'停止使用';
        }

        $this->assign('result',$a);
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('enterSortList');
    }

    public function enterSortAdd()
    {
        return $this->fetch();
    }

    public function enterSortAddHandle()
    {
        $fileName = "/public/upload/entertainment/".$_FILES["img"]["name"];
        move_uploaded_file($_FILES["img"]["tmp_name"], "." . $fileName);
        $en_name    =   $_POST['en_name'];
        $state    =   $_POST['state'];
        $sort    =   $_POST['sort'];
        $img    =   $fileName;
        $add_time   =   date(("Y-m-d H:i:s"),time());
//var_dump($img);exit;
        $sql=sprintf("insert into tp_entertainment(en_name,state,sort,img,add_time) VALUES ('%s','%s','%s','%s','%s')",$en_name,$state,$sort,$img,$add_time);
        Db::query($sql);

        if ($sql) {
            $this->success("操作成功", U('Admin/Entertainment/enterSortList'));
        } else {
            $this->error("操作失败", U('Admin/Entertainment/enterSortList'));
        }

    }


    /**
     * 初始化编辑器链接
     * @param $post_id post_id
     */
    private function initEditor()
    {
        $this->assign("URL_upload", U('Admin/Ueditor/imageUp', array('savepath' => 'article')));
        $this->assign("URL_fileUp", U('Admin/Ueditor/fileUp', array('savepath' => 'article')));
        $this->assign("URL_scrawlUp", U('Admin/Ueditor/scrawlUp', array('savepath' => 'article')));
        $this->assign("URL_getRemoteImage", U('Admin/Ueditor/getRemoteImage', array('savepath' => 'article')));
        $this->assign("URL_imageManager", U('Admin/Ueditor/imageManager', array('savepath' => 'article')));
        $this->assign("URL_imageUp", U('Admin/Ueditor/imageUp', array('savepath' => 'article')));
        $this->assign("URL_getMovie", U('Admin/Ueditor/getMovie', array('savepath' => 'article')));
        $this->assign("URL_Home", "");
    }

    public function staffListAddHandle()
    {

        $fileName = "/public/upload/cloud/" . time() . $_FILES["img"]["name"];
        move_uploaded_file($_FILES["img"]["tmp_name"], "." . $fileName);
        $em_name = $_POST['em_name'];
        $em_number = $_POST['em_number'];
        $position = $_POST['position'];
        $level = $_POST['level'];
        $tel = $_POST['tel'];
        $email = $_POST['email'];
        $img = $fileName;
        $work_life = $_POST['work_life'];
        $genius = $_POST['genius'];
        echo implode($genius, ' ');

        $mysql=sprintf("select em_number from tp_cloud_employee WHERE em_number=%d",$em_number);
        $res=Db::query($mysql);
//        var_dump($res);exit;
        if(!empty($res)){
            echo "<script type='text/javascript'>alert('该员工编号已存在，请重新输入！');location.href='staffListAdd';</script>";
        }else{
            $sql = sprintf("INSERT INTO tp_cloud_employee (em_name,em_number,position,level,tel,email,img) VALUES ('%s','%s','%s','%s','%s','%s','%s')", $em_name, $em_number, $position, $level, $tel, $email, $img);
            Db::query($sql);
            $sql2 = sprintf("select employee_id from tp_cloud_employee order BY employee_id DESC limit 0,1");
            $b = Db::query($sql2);
            $sql1 = sprintf("INSERT INTO tp_cloud_author (a_name, genius,work_life,employee_id) VALUES ('%s','%s','%s',%d)", $em_name, implode($genius, ','), $work_life, $b[0]['employee_id']);
            Db::query($sql1);
        }

        if ($sql) {
            $this->success("操作成功", U('Admin/Staff/staffList'));
        } else {
            $this->error("操作失败", U('Admin/Staff/staffList'));
        }
    }

    public function staffListEditHandle()
    {
        $dddd = $_GET['employee_id'];
        $sql = sprintf("select tp_cloud_employee.*,tp_cloud_author.* from tp_cloud_employee LEFT JOIN tp_cloud_author ON tp_cloud_employee.employee_id=tp_cloud_author.employee_id WHERE tp_cloud_employee.employee_id=%d", $dddd);
        $a = Db::query($sql);
        $this->assign('result', $a[0]);
        return $this->fetch('staffListEdit');

    }

    public function staffListUpdate()
    {
        $employee_id=$_GET['employee_id'];
        $em_name = $_POST['em_name'];
        $em_number = $_POST['em_number'];
        $position = $_POST['position'];
        $level = $_POST['level'];
        $tel = $_POST['tel'];
        $email = $_POST['email'];
        $work_life = $_POST['work_life'];
        $genius = $_POST['genius'];

//        var_dump($ccc['genius']);exit;
        $bb = implode($genius, ' ');
//        var_dump($bb);exit;
            $sql1 = sprintf("UPDATE tp_cloud_employee SET em_name = '%s',em_number = '%s',position = '%s',level = '%s',tel = '%s',email = '%s' WHERE employee_id = %d", $em_name, $em_number, $position,$level,$tel, $email, $employee_id);
            Db::query($sql1);
            $sql2 = sprintf("UPDATE tp_cloud_author SET a_name = '%s',genius = '%s',work_life = '%s' WHERE employee_id = %d", $em_name, $bb, $work_life, $employee_id);
            Db::query($sql2);
//            var_dump($sql2);exit;
        if ($sql1) {
            $this->success("操作成功", U('Admin/Staff/staffList'));
        } else {
            $this->error("操作失败", U('Admin/Staff/staffList'));
        }

    }

    public function staffListDeleteHandle()
    {
        $data = I('post.');
//        var_dump($data);exit;
        if($data['act'] == 'del'){
//            $sql=sprintf('DELETE FROM tp_cloud_employee WHERE employee_id = %d');
//            $vv=Db::query($sql);
            $r = D('cloud_employee')->where('employee_id', $data['del_id'])->delete();
            if($r) exit(json_encode(1));
        }
        $referurl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : U('Admin/Staff/staffList');
        // 不管是添加还是修改广告 都清除一下缓存
        delFile(RUNTIME_PATH.'html'); // 先清除缓存, 否则不好预览

        if($r){
            $this->success("操作成功",U('Admin/Staff/staffList'));
        }else{
            $this->error("操作失败",$referurl);
        }
    }
}