<?php
/**
 * tpshop
 * ============================================================================
 * 版权所有 2015-2027 深圳搜豹网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.tp-shop.cn
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用 .
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * Author: 当燃      
 * Date: 2015-09-09
 */
namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Activity extends Base {

    private $article_system_id = array(1, 2, 3, 4, 5);//系统默认的文章分类id，不可删除
    private $article_main_system_id = array(1, 2);//系统保留分类，不允许在该分类添加文章
    private $article_top_system_id = array(1);//系统分类，不允许在该分类添加新的分类
    private $article_able_id = array(1);//系统预定义文章id，不能删除。此文章用于商品详情售后服务

    public function _initialize()
    {
        parent::_initialize();
        $this->assign('article_top_system_id', $this->article_top_system_id);
        $this->assign('article_system_id', $this->article_system_id);
        $this->assign('article_main_system_id', $this->article_main_system_id);
        $this->assign('article_able_id',$this->article_able_id);
    }

    public function categoryList(){
        $ArticleCat = new ArticleCatLogic(); 
        $cat_list = $ArticleCat->article_cat_list(0, 0, false);
        $type_arr = array('系统默认','系统帮助','系统公告');
        $this->assign('type_arr',$type_arr);
        $this->assign('cat_list',$cat_list);
        return $this->fetch('categoryList');
    }

    public function activityList(){
        $Activity =  M('Activity');
        $list = array();
        $p = input('p/d', 1);
        $size = input('size/d', 20);
        $where = array();
        $keywords = trim(I('keywords'));
        $keywords && $where['activity_name'] = array('like', '%' . $keywords . '%');
        $cat_id = I('cat_id/d',0);
        $cat_id && $where['cat_id'] = $cat_id;
        $res = $Activity->where($where)->order('activity_id desc')->page("$p,$size")->select();
        $count = $Activity->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count,$size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        if($res){
        	foreach ($res as $val){
        		$list[] = $val;
        	}
        }
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$page);// 赋值分页输出
        $this->assign('pager',$pager);
        return $this->fetch('activityList');
    }
    
    public function activity(){
 		$act = I('get.act','add');
        $info = array();
        $info['add_time'] = time()+3600*24;
        $activity_id = I('get.activity_id/d');
        if($activity_id){
           $info = D('activity')->where('activity_id', $activity_id)->find();
        }
        $this->assign('act',$act);
        $this->assign('info',$info);
        $this->initEditor();
        return $this->fetch();
    }

    /**
     * 初始化编辑器链接
     * @param $post_id post_id
     */
    private function initEditor()
    {
        $this->assign("URL_upload", U('Admin/Ueditor/imageUp',array('savepath'=>'article')));
        $this->assign("URL_fileUp", U('Admin/Ueditor/fileUp',array('savepath'=>'article')));
        $this->assign("URL_scrawlUp", U('Admin/Ueditor/scrawlUp',array('savepath'=>'article')));
        $this->assign("URL_getRemoteImage", U('Admin/Ueditor/getRemoteImage',array('savepath'=>'article')));
        $this->assign("URL_imageManager", U('Admin/Ueditor/imageManager',array('savepath'=>'article')));
        $this->assign("URL_imageUp", U('Admin/Ueditor/imageUp',array('savepath'=>'article')));
        $this->assign("URL_getMovie", U('Admin/Ueditor/getMovie',array('savepath'=>'article')));
        $this->assign("URL_Home", "");
    }
    
    public function activityHandle(){
        $fileName = "/public/upload/qrCode/". time() . $_FILES["pic"]["name"];
        move_uploaded_file($_FILES["pic"]["tmp_name"], "." . $fileName);
        $data = I('post.');
        $data['content'] = I('content'); // 文章内容单独过滤
        $data['add_time'] = strtotime($data['add_time']);

        $url = $this->request->server('HTTP_REFERER');
        $referurl = !empty($url) ? $url : U('Admin/Activity/activityList');

        if($data['act'] == 'add'){

            if(array_key_exists($data['cat_id'],$this->article_main_system_id)){
                $this->error("不能在系统保留分类下添加文章,操作失败",$referurl);

            }

            $data['click'] = mt_rand(1000,1300);
            $data['add_time'] =date("Y-m-d H:m:s",time()) ;
            $data['pic'] = $fileName;
            $r = D('activity')->add($data);

        }

        if($data['act'] == 'edit'){
            $r = M('activity')->where('activity_id', $data['activity_id'])->save($data);
        }
        
        if($data['act'] == 'del'){
            if(array_key_exists($data['activity_id'],$this->activity_id)){
                exit(json_encode('系统预定义的文章不能删除'));
            }
        	$r = D('activity')->where('activity_id', $data['activity_id'])->delete();

        	if($r) exit(json_encode(1));       	
        }
        if($r){

            $this->success("操作成功",$referurl);

        }else{
            $this->error("操作失败",$referurl);
        }

    }
    
    
    public function link(){
    	$act = I('get.act','add');
    	$this->assign('act',$act);
    	$link_id = I('get.link_id/d');
    	$link_info = array();
    	if($link_id){
    		$link_info = D('friend_link')->where('link_id', $link_id)->find();
    	}
        $this->assign('info',$link_info);
    	return $this->fetch();
    }
    
    public function linkList(){
    	$Ad =  M('friend_link');
        $p = $this->request->param('p');
    	$res = $Ad->where('1=1')->order('orderby')->page($p.',10')->select();
    	if($res){
    		foreach ($res as $val){
    			$val['target'] = $val['target']>0 ? '开启' : '关闭';
    			$list[] = $val;
    		}
    	}
    	$this->assign('list',$list);// 赋值数据集
    	$count = $Ad->where('1=1')->count();// 查询满足要求的总记录数
    	$Page = new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
    	$show = $Page->show();// 分页显示输出
        $this->assign('pager',$Page);// 赋值分页输出
    	$this->assign('page',$show);// 赋值分页输出
    	return $this->fetch();
    }
    
    public function linkHandle(){
        $data = I('post.');
    	if($data['act'] == 'add'){
    		stream_context_set_default(array('http'=>array('timeout' =>2)));
//            send_http_status('311');
    		$r = D('friend_link')->insert($data);
    	}
    	if($data['act'] == 'edit'){
    		$r = D('friend_link')->where('link_id', $data['link_id'])->save($data);
    	}
    	
    	if($data['act'] == 'del'){
    		$r = D('friend_link')->where('link_id', $data['link_id'])->delete();
    		if($r) exit(json_encode(1));
    	}
    	
    	if($r){
    		$this->success("操作成功",U('Admin/Article/linkList'));
    	}else{
    		$this->error("操作失败",U('Admin/Article/linkList'));
    	}
    }

}