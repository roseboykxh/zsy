<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/7/21
 * Time: 15:45
 */

namespace app\admin\controller;
use think\Db;

class GardenImage extends Base
{
    public function index(){
        $sql = sprintf("SELECT g.garden_id,c.nickname,c.tree_name,g.tree_image,g.id
                FROM tp_garden c ". "inner JOIN tp_tree_image g ON g.garden_id = c.id ")
               ;
        $result = Db::query($sql);
       // var_dump($result);exit;
        $this->assign('smsTplList',$result);
        return $this->fetch();

    }
    /**
     * 添加树木
     */
    public  function addEditGardenImage(){
        return $this->fetch();
    }

    public  function addGardenImage(){

        $kzmArr=explode('.',$_FILES['tree_image']['name']);
        $kzm=$kzmArr[count($kzmArr)-1];
        $newName=time().'.'.$kzm;
        $lastFilePath='/public/upload/qrCode/'.$newName;
        move_uploaded_file($_FILES['tree_image']['tmp_name'],dirname(dirname(dirname(dirname(__FILE__)))).$lastFilePath);
        $garden_id =  $_POST['garden_id'];
        $tree_image = $lastFilePath;


        $resArr=  M('tree_image')->add(array(
            'garden_id' => $garden_id,
            'tree_image' => $tree_image,
        ));
        $this->assign('resArr',$resArr);
        echo "添加成功";
        header("refresh:1;url=index");//$url就是你的跳转路径

    }

    /**
     * 修改
     */
    public function updateGardenImage(

    ){
        $id = $_GET['id']; //用户id
        //列表自定义查询列
        $filed = array(
            'id',
            'garden_id',
            'tree_image',
        );
        $resArr = M('tree_image')-> field(implode(',', $filed))->where('id',$id)->select();

        $this->assign('resArr',$resArr);
        return $this->fetch();
    }
    public function updateGardenImage2(){
        $kzmArr=explode('.',$_FILES['tree_image']['name']);
        $kzm=$kzmArr[count($kzmArr)-1];
        $newName=time().'.'.$kzm;
        $lastFilePath='/public/upload/qrCode/'.$newName;
        move_uploaded_file($_FILES['tree_image']['tmp_name'],dirname(dirname(dirname(dirname(__FILE__)))).$lastFilePath);
        $id = $_POST['id'];
        $garden_id =  $_POST['garden_id'];
        $tree_image = $lastFilePath;

        $resArr=  M('tree_image')->where(array('id'=>$id))->
        save(array(
            'garden_id' => $garden_id,
            'tree_image' => $tree_image,
                    ));
        $this->assign('resArr',$resArr);
        echo "修改成功";
        header("refresh:1;url=index");//$url就是你的跳转路径
    }

    /**
     * 删除
     */
    public function delGardenImage(){

        $model = M("tree_image");
        $row = $model->where('id ='.$_GET['id'])->delete();
        $return_arr = array();
        if ($row){
            $return_arr = array('status' => 1,'msg' => '删除成功','data'  =>'',);   //$return_arr = array('status' => -1,'msg' => '删除失败','data'  =>'',);
        }else{
            $return_arr = array('status' => -1,'msg' => '删除失败','data'  =>'',);
        }
        return $this->ajaxReturn($return_arr);

    }

}