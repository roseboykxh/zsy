<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/7/20
 * Time: 14:01
 */

namespace app\admin\controller;


class Orchardist extends Base {
    public function index(){
        $sms = M('orchardist')->select();
        $this->assign('smsTpl',$sms);
        return $this->fetch();
    }

    /**
     * 添加树木
     */
    public  function addEditOrchardist(){
        return $this->fetch();
    }

    public  function addOrchardist(){
            $provider =  $_POST['provider'];
            $orchard_site = $_POST['orchard_site'];
            $longitude = $_POST['longitude'];   //经度
            $latitude = $_POST['latitude'];       //纬度
            $orchard_area = $_POST['orchard_area'];
            $tree_number = $_POST['tree_number'];
            $tree_species = $_POST['tree_species'];
            $tree_covers = $_POST['tree_covers'];  //每棵树占地
            $market_price = $_POST['market_price'];
            $member_price = $_POST['member_price'];
            $promotional_price = $_POST['promotional_price'];

                $resArr=  M('orchardist')->add(array('provider' => $provider,
                                                        'orchard_site' => $orchard_site,
                                                        'longitude' => $longitude,
                                                        'latitude' => $latitude,
                                                        'orchard_area' => $orchard_area,
                                                        'tree_number' => $tree_number,
                                                        'tree_species' => $tree_species,
                                                        'tree_covers' => $tree_covers,
                                                        'market_price' => $market_price,
                                                        'member_price' => $member_price,
                                                        'promotional_price' => $promotional_price,
                                                    ));
                  $this->assign('resArr',$resArr);
                    echo "添加成功";
                    header("refresh:1;url=index");//$url就是你的跳转路径

    }

    /**
     * 修改
     */
    public function updateOrchardist(

    ){
        $id = $_GET['id']; //用户id
        //列表自定义查询列
        $filed = array(
            'id',
            'provider',
            'orchard_site',
            'longitude',
            'latitude',
            'orchard_area',
            'tree_number',
            'tree_species',
            'tree_covers',
            'market_price',
            'member_price',
            'promotional_price'
        );
        $resArr = M('orchardist')-> field(implode(',', $filed))->where('id',$id)->select();

        $this->assign('resArr',$resArr);
        return $this->fetch();
    }
    public function updateOrchardist2(){
        $id = $_POST['id'];
        $provider =  $_POST['provider'];
        $orchard_site = $_POST['orchard_site'];
        $longitude = $_POST['longitude'];   //经度
        $latitude = $_POST['latitude'];       //纬度
        $orchard_area = $_POST['orchard_area'];
        $tree_number = $_POST['tree_number'];
        $tree_species = $_POST['tree_species'];
        $tree_covers = $_POST['tree_covers'];  //每棵树占地
        $market_price = $_POST['market_price'];
        $member_price = $_POST['member_price'];
        $promotional_price = $_POST['promotional_price'];

        $resArr=  M('orchardist')->where(array('id'=>$id))->
        save(array(
            'provider' => $provider,
            'orchard_site' => $orchard_site,
            'longitude' => $longitude,
            'latitude' => $latitude,
            'orchard_area' => $orchard_area,
            'tree_number' => $tree_number,
            'tree_species' => $tree_species,
            'tree_covers' => $tree_covers,
            'market_price' => $market_price,
            'member_price' => $member_price,
            'promotional_price' => $promotional_price,));
        $this->assign('resArr',$resArr);
        echo "修改成功";
        header("refresh:1;url=index");//$url就是你的跳转路径
    }

    /**
     * 删除
     */
    public function delOrchardist(){

        $model = M("orchardist");
        $row = $model->where('id ='.$_GET['id'])->delete();
        $return_arr = array();
        if ($row){
            $return_arr = array('status' => 1,'msg' => '删除成功','data'  =>'',);   //$return_arr = array('status' => -1,'msg' => '删除失败','data'  =>'',);
        }else{
            $return_arr = array('status' => -1,'msg' => '删除失败','data'  =>'',);
        }
        return $this->ajaxReturn($return_arr);

    }
}



