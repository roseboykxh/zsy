<?php
/**
 * tpshop
 * ============================================================================
 * 版权所有 2015-2027 深圳搜豹网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.tp-shop.cn
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用 .
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * Author: 当燃
 * Date: 2015-09-09
 */
namespace app\admin\controller;

use think\Page;
use app\admin\logic\ArticleCatLogic;
use think\Db;

class Lesson extends Base
{

    private $article_system_id = array(1, 2, 3, 4, 5);//系统默认的文章分类id，不可删除
    private $article_main_system_id = array(1, 2);//系统保留分类，不允许在该分类添加文章
    private $article_top_system_id = array(1);//系统分类，不允许在该分类添加新的分类
    private $article_able_id = array(1);//系统预定义文章id，不能删除。此文章用于商品详情售后服务

    public function _initialize()
    {
        parent::_initialize();
        $this->assign('article_top_system_id', $this->article_top_system_id);
        $this->assign('article_system_id', $this->article_system_id);
        $this->assign('article_main_system_id', $this->article_main_system_id);
        $this->assign('article_able_id', $this->article_able_id);
    }

    public function lessonDetail()
    {
        $Cloud_classroom_detail = M('Cloud_classroom_detail ');
        $list = array();
        $size = input('size/d', 20);
        $where = array();
        $count = $Cloud_classroom_detail ->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        $sql=sprintf("select td.crd_id,td.crt_id,td.v_img,td.v_name,td.v_intro,td.add_time,td.author_id,td.v_path,tc.cr_name,ta.a_name
                      from tp_cloud_classroom_detail td LEFT JOIN tp_cloud_classroom_category tc ON td.crt_id=tc.crt_id
                      LEFT JOIN tp_cloud_author ta ON td.author_id=ta.author_id");
        $mysql=Db::query($sql);
//        var_dump($mysql);exit;
        $this->assign('result',$mysql);

        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        return $this->fetch('lessonDetail');

    }

    public function lessonDetailAdd()
    {
        $sql    =   sprintf("select cr_name from tp_cloud_classroom_category");
        $mysql=Db::query($sql);
        $sql1    =   sprintf("select a_name from tp_cloud_author");
        $mysql1=Db::query($sql1);
//        var_dump($mysql);exit;
        $this->assign('list',$mysql1);
        $this->assign('result',$mysql);
        return $this->fetch();
    }

    public function lessonAdd()
    {

        $Cloud_classroom_detail = M('Cloud_classroom_detail ');
        $list = array();
        $size = input('size/d', 20);
        $where = array();
        $count = $Cloud_classroom_detail ->where($where)->count();// 查询满足要求的总记录数
        $pager = new Page($count, $size);// 实例化分页类 传入总记录数和每页显示的记录数
        $page = $pager->show();//分页显示输出

        $fileName = "/public/upload/cloud/".$_FILES["v_img"]["name"];
        move_uploaded_file($_FILES["v_img"]["tmp_name"], "." . $fileName);
        $crd_id=$_POST['crd_id'];
        $cr_name=$_POST['cr_name'];
        $v_img=$fileName;
        $v_name=$_POST['v_name'];
        $v_intro=$_POST['v_intro'];
        $a_name=$_POST['a_name'];
        $v_path=$_POST['v_path'];
        $add_time =date("Y-m-d H:m:s",time()) ;

        $sql1=sprintf("select tp_cloud_classroom_detail.crt_id,tp_cloud_classroom_detail.author_id from tp_cloud_classroom_detail 
                        LEFT JOIN tp_cloud_classroom_category  ON tp_cloud_classroom_detail.crt_id=tp_cloud_classroom_category.crt_id
                        LEFT JOIN tp_cloud_author ON tp_cloud_classroom_detail.author_id=tp_cloud_author.author_id");
        $b=Db::query($sql1);
//        var_dump($b);exit;
        $sql=sprintf("insert into tp_cloud_classroom_detail (crd_id,crt_id,v_img,v_name,v_intro,add_time,author_id,v_path) 
                      VALUES (%d,%d,'%s','%s','%s','%s',%d,'%s')",$crd_id,$cr_name,$v_img,$v_name,$v_intro,$add_time,$a_name,$v_path);
        $a=Db::query($sql);
//        var_dump($a);exit;
        $this->assign('result',$a);
        $this->assign('list', $list);// 赋值数据集
        $this->assign('page', $page);// 赋值分页输出
        $this->assign('pager', $pager);
        if ($sql) {
            $this->success("操作成功", U('Admin/Lesson/lessonDetail'));
        } else {
            $this->error("操作失败", U('Admin/Lesson/lessonDetail'));
        }
    }

    public function lessonDetailEdit()
    {
        $act = I('get.act','add');
        $info = array();
        $data['add_time'] =date("Y-m-d H:m:s",time());
        $crd_id = I('get.crd_id/d');
//        var_dump($crd_id);exit;
        if($crd_id){
            $info = D('cloud_classroom_detail')->where('crd_id', $crd_id)->find();
        }
//var_dump($info);exit;
        $category = D('cloud_classroom_category')->select();
        $this->assign('category', $category);

        $author = D('cloud_author')->select();
        $this->assign('author', $author);

        $this->assign('act',$act);
        $this->assign('info',$info);
        $this->initEditor();
        return $this->fetch();
    }


    /**
     * 初始化编辑器链接
     * @param $post_id post_id
     */
    private function initEditor()
    {
        $this->assign("URL_upload", U('Admin/Ueditor/imageUp',array('savepath'=>'article')));
        $this->assign("URL_fileUp", U('Admin/Ueditor/fileUp',array('savepath'=>'article')));
        $this->assign("URL_scrawlUp", U('Admin/Ueditor/scrawlUp',array('savepath'=>'article')));
        $this->assign("URL_getRemoteImage", U('Admin/Ueditor/getRemoteImage',array('savepath'=>'article')));
        $this->assign("URL_imageManager", U('Admin/Ueditor/imageManager',array('savepath'=>'article')));
        $this->assign("URL_imageUp", U('Admin/Ueditor/imageUp',array('savepath'=>'article')));
        $this->assign("URL_getMovie", U('Admin/Ueditor/getMovie',array('savepath'=>'article')));
        $this->assign("URL_Home", "");
    }

    public function lessonDetailAddHandle()
    {
//        var_dump($_REQUEST);exit;
        $fileName = "/public/upload/cloud/" . time() . $_FILES["v_img"]["name"];
        move_uploaded_file($_FILES["v_img"]["tmp_name"], "." . $fileName);
        $data = I('post.');

        $data['v_intro'] = I('v_intro'); // 文章内容单独过滤

        if ($data['act'] == 'add') {

            $data['click'] = mt_rand(1000, 1300);
            $data['v_img'] = $fileName;
            $data['add_time'] = date("Y-m-d H:m:s", time());
            $r = D('cloud_classroom_detail')->add($data);
            $sql=sprintf("select tp_cloud_classroom_detail.crt_id,tp_cloud_classroom_detail.author_id,tp_cloud_classroom_category.cr_name,tp_cloud_author.a_name
                            from tp_cloud_classroom_detail LEFT JOIN tp_cloud_classroom_category ON tp_cloud_classroom_detail.crt_id=tp_cloud_classroom_category.crt_id
                            LEFT JOIN tp_cloud_author ON tp_cloud_classroom_detail.author_id=tp_cloud_author.author_id");
            Db::query($sql);
//            var_dump($sql);exit;
//            var_dump($data);exit;
        }

        if($data['act'] == 'edit'){
            $data['v_img'] = $fileName;
            $r = M('cloud_classroom_detail')->where('crd_id', $data['crd_id'])->save($data);
        }

        if ($data['act'] == 'del') {
            $r = D('cloud_classroom_detail')->where('crd_id', $data['del_id'])->delete();
            if ($r) exit(json_encode(1));
        }
        $referurl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : U('Admin/Lesson/lessonDetail');
        // 不管是添加还是修改广告 都清除一下缓存
        delFile(RUNTIME_PATH . 'html'); // 先清除缓存, 否则不好预览

        if ($r) {
            $this->success("操作成功", U('Admin/Lesson/lessonDetail'));
        } else {
            $this->error("操作失败", $referurl);
        }
    }


    public function link()
    {
        $act = I('get.act', 'add');
        $this->assign('act', $act);
        $link_id = I('get.link_id/d');
        $link_info = array();
        if ($link_id) {
            $link_info = D('friend_link')->where('link_id', $link_id)->find();
        }
        $this->assign('info', $link_info);
        return $this->fetch();
    }

    public function linkList()
    {
//        var_dump($_POST);
        $Ad = M('friend_link');
        $p = $this->request->param('p');
        $res = $Ad->where('1=1')->order('orderby')->page($p . ',10')->select();
        if ($res) {
            foreach ($res as $val) {
                $val['target'] = $val['target'] > 0 ? '开启' : '关闭';
                $list[] = $val;
            }
        }
        $this->assign('list', $list);// 赋值数据集
        $count = $Ad->where('1=1')->count();// 查询满足要求的总记录数
        $Page = new Page($count, 10);// 实例化分页类 传入总记录数和每页显示的记录数
        $show = $Page->show();// 分页显示输出
        $this->assign('pager', $Page);// 赋值分页输出
        $this->assign('page', $show);// 赋值分页输出
        return $this->fetch();
    }

    public function linkHandle()
    {
        $data = I('post.');
        if ($data['act'] == 'add') {
            stream_context_set_default(array('http' => array('timeout' => 2)));
//            send_http_status('311');
            $r = D('friend_link')->insert($data);
        }
        if ($data['act'] == 'edit') {
            $r = D('friend_link')->where('link_id', $data['link_id'])->save($data);
        }

        if ($data['act'] == 'del') {
            $r = D('friend_link')->where('link_id', $data['link_id'])->delete();
            if ($r) exit(json_encode(1));
        }

        if ($r) {
            $this->success("操作成功", U('Admin/Article/linkList'));
        } else {
            $this->error("操作失败", U('Admin/Article/linkList'));
        }
    }

}